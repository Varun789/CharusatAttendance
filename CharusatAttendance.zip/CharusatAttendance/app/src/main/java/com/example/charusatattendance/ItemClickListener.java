package com.example.charusatattendance;

import android.view.View;

public interface ItemClickListener {
    void onItemClickListener(View view, int position);
}
